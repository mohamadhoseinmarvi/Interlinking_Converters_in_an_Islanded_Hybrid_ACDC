clear all; close all; clc;

n0 = [1, 2, 4, 3, 4];
n1 = [2, 3, 3, 4, 1];

r = [0, 2, 5, 10, 0];

Vs = [20, 0, 0, 0, 0];

D = 3;

C = circuit(n0, n1, r, Vs, D);

results = C.get_results('IVP').numeric;

C.print_results();

C.plot_circuit('I');