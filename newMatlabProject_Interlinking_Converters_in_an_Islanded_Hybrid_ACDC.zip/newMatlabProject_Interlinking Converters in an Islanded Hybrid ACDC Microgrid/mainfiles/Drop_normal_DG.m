classdef circuit
    properties
        Graph
        Impedance
        Diodes
        Source
        Currents
        PotentialDiffs
        Powers
    end
    methods
        function C = circuit(e1,e2,Impedance,Source,varargin)
            if size(Impedance,1) ~= length(Impedance)
                Impedance = Impedance.';
            end
            if size(Source,1) ~= length(Source)
                Source = Source.';
            end
            C.Graph = dioGraph(e1,e2);
            C.Impedance = Impedance;
            C.Source = Source;
            if ~isempty(varargin)
                C.Diodes = varargin{1};
                [I,V,P] = circuit.solve_circuit_diodes(C.Graph,Impedance,Source,varargin{1});
            else
                C.Diodes = [];
                [I,V,P] = circuit.solve_circuit(C.Graph,Impedance,Source);
            end
            C.Currents = I;
            C.PotentialDiffs = V;
            C.Powers = P;
        end
        
        function [] = plot_circuit(C,varargin)
            if isempty(varargin)
                C.Graph.plot_graph();
            else
                if isempty(varargin{1})
                    u = 1:length(C.Currents);
                else
                    switch varargin{1}
                        case 'I'
                            u = abs(C.Currents);
                        case 'V'
                            u = abs(C.PotentialDiffs);
                        case 'P'
                            u = abs(C.Powers);
                    end
                end
                is3D = false;
                if length(varargin) > 1
                    if strcmp(varargin{2},'3D')
                        is3D = true;
                    end
                end
                C.Graph.plot_graph(u,is3D)
                title('Circuit plot');
            end
        end
        
        function results = get_results(C,res)
            I = circuit.polar_form(C.Currents,'deg');
            V = circuit.polar_form(C.PotentialDiffs,'deg');
            P = C.Powers;
            Z = C.Impedance;
            Edges = [1:length(I)]';
            results.display = [table(Edges),table(Z)];
            for n = 1:length(res)
                switch res(n)
                    case 'I'
                        results.display = [results.display, table(I)];
                    case 'V'
                        results.display = [results.display, table(V)];
                    case 'P'
                        results.display = [results.display, table(P)];
                end
            end
            I = C.Currents;
            V = C.PotentialDiffs;
            P = C.Powers;
            Z = C.Impedance;
            Edges = [1:length(I)]';
            results.numeric = [table(Edges),table(Z)];
            for n = 1:length(res)
                switch res(n)
                    case 'I'
                        results.numeric = [results.numeric, table(I)];
                    case 'V'
                        results.numeric = [results.numeric, table(V)];
                    case 'P'
                        results.numeric = [results.numeric, table(P)];
                end
            end
        end
        
        function [] = print_results(C)
            results = C.get_results('IVP');
            fprintf('\n');
            disp(results.display);
        end
        
    end
    
    methods(Static)
        
        function [I,V,P] = solve_circuit_diodes(Graph,Impedance,Source,Diodes)
            
            run = true;
            while run
                
                [I,V,P] = circuit.solve_circuit(Graph,Impedance,Source);
                
                k = 0;
                for n = Diodes
                    if (I(n) < 0)&&(abs(I(n)) > 1e-5)
                        Impedance(n) = 1e20;
                        k = k + 1;
                    end
                end
                
                if k == 0
                    run = false;
                end
                
            end
            
        end
        
        function [I,V,P] = solve_circuit(Graph,Impedance,Source)
            A = Graph.incidence_matrix();
            Z = diag(Impedance);
            N = null(A','r');
            K = rref(A');
            K = K(1:end-1,:);
            D = [N'*Z; K];
            d = [N'*Source; zeros(size(D,1)-length(N'*Source),1)];
            I = D^-1*d;
            V = Z*I+Source;
            P = Impedance.*(abs(I).^2);
            
        end
        
        function out = polar_form(A,varargin)
            if all(imag(A) == 0)
                out = A;
            else
                absA = abs(A);
                if ~isempty(varargin) & (varargin{1} == 'deg')
                    phaseA = angle(A)*180/pi;
                else
                    phaseA = angle(A);
                end
                out = arrayfun(@(x, y) sprintf('%0.3f < %0.3f', x, y), absA, phaseA, 'uni', 0);
            end
        end
        
    end
end