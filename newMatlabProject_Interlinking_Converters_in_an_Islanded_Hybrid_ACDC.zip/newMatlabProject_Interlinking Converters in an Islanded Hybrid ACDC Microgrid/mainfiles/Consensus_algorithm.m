clear all; close all; clc;

n0 = [1, 2, 3, 4, 2, 3, 4, 1, 5];
n1 = [2, 3, 4, 1, 5, 6, 6, 5, 6];

z = [0, 2+1i, 5-3i, 0, 1, 1+1i, 0, 4, 1];

Vs = [120*exp(0.2i), 0, 0, 0, 0, 0, 0, 0, 0];


C = circuit(n0, n1, z, Vs);

results = C.get_results('IVP').numeric;

C.print_results();

C.plot_circuit('I','3D');