function options = Mdoption

options = [ 
    1;               
    1e-4;           
    1e-3;           
    1e2;            
    
    1;              
    1;             
];

return;