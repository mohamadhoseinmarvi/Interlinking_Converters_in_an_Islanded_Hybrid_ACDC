function Pgov = Loadgov(casefile_dyn)

if isstruct(casefile_dyn)
	gov = casefile_dyn.gov;
else
    [gen,exc,gov,mmc,DCVolCon,OutCurCon,CirCurCon,freq,stepsize,stoptime] = feval(casefile_dyn);
end

Pgov = gov;

for i = 1:length(gov(1,:))
    Pgov(gov(:,1),i) = gov(:,i);
end

return;