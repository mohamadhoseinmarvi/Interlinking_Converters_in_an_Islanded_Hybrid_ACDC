function Pgen = Loadgen(casefile_dyn, output)

if isstruct(casefile_dyn)
    gen = casefile_dyn.gen;
else
    [gen,exc,gov,mmc,DCVolCon,OutCurCon,CirCurCon,freq,stepsize,stoptime] = feval(casefile_dyn);
end

Pgen = gen;

genmodel = Pgen(:,1);


d=[1:length(genmodel)]';
type1 = d(genmodel==1);
type2 = d(genmodel==2);


xd_tr = Pgen(type2,8);
xq_tr = Pgen(type2,9);

if sum(xd_tr~=xq_tr)>=1
    if output; fprintf('> Warning: transient saliency not supported\n                                     '); end
    Pgen(type2,9) = Pgen(type2,8);
end

return;