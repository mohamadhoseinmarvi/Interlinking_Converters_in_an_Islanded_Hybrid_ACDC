function mpc = add_userfcn(mpc, stage, fcn, args, allow_multiple)

if nargin < 5
    allow_multiple = 0;
    if nargin < 4
        args = [];
    end
end
switch stage
    case {'ext2int', 'formulation', 'int2ext', 'printpf', 'savecase'}
        %% ok
    otherwise
        error('add_userfcn : ''%s'' is not the name of a valid callback stage\n', stage);
end

n = 1;
if isfield(mpc, 'userfcn')
    if isfield(mpc.userfcn, stage)
        n = length(mpc.userfcn.(stage)) + 1;
        if ~allow_multiple
            if have_fcn('octave')
                fcn_info = functions(fcn);
                for k = 1:n-1
                    cb_info = functions(mpc.userfcn.(stage)(k).fcn);
                    if strcmp(cb_info.function, fcn_info.function)
                        error('add_userfcn: the function ''%s'' has already been added', func2str(fcn));
                    end
                end
            else
                for k = 1:n-1
                    if isequal(mpc.userfcn.(stage)(k).fcn, fcn)
                        error('add_userfcn: the function ''%s'' has already been added', func2str(fcn));
                    end
                end
            end
        end
    end
end

mpc.userfcn.(stage)(n).fcn = fcn;
if ~isempty(args)
    mpc.userfcn.(stage)(n).args = args;
end
