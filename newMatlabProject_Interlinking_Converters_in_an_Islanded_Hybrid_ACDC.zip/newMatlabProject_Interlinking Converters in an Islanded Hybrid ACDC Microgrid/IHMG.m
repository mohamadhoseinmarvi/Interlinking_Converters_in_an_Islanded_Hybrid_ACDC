function [Ly, Uy, Py] = AugYbus(baseMVA, bus, branch, xd_tr, gbus, P, Q, U0)

Ybus = makeYbus(baseMVA, bus, branch);

yload = (P - 1j.*Q)./(abs(U0).^2);

ygen=zeros(size(Ybus,1),1);
ygen(gbus) = 1./(1j.*xd_tr);

ygen(2) = 0;

for i=1:size(Ybus,1)
    Ybus(i,i) = Ybus(i,i) + ygen(i) + yload(i);
end

Y = Ybus;

[Ly,Uy,Py] = lu(Y,'vector');

return;