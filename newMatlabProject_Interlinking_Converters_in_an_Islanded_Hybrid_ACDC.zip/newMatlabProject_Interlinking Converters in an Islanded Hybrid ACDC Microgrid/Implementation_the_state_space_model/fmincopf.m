function [varargout] = fmincopf(varargin)

[mpc, mpopt] = opf_args(varargin{:});
mpopt = mpoption(mpopt, 'PF_DC', 0, 'OPF_ALG', 520);
[varargout{1:nargout}] = opf(mpc, mpopt);
