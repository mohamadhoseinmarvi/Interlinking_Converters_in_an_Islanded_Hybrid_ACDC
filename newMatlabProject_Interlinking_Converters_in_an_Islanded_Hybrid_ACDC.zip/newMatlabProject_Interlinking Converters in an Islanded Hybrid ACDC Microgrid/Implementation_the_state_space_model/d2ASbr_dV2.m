function [Haa, Hav, Hva, Hvv] = ...
    d2ASbr_dV2(dSbr_dVa, dSbr_dVm, Sbr, Cbr, Ybr, V, lam)
nl = length(lam);

diaglam = sparse(1:nl, 1:nl, lam, nl, nl);
diagSbr_conj = sparse(1:nl, 1:nl, conj(Sbr), nl, nl);

[Saa, Sav, Sva, Svv] = d2Sbr_dV2(Cbr, Ybr, V, diagSbr_conj * lam);
Haa = 2 * real( Saa + dSbr_dVa.' * diaglam * conj(dSbr_dVa) );
Hva = 2 * real( Sva + dSbr_dVm.' * diaglam * conj(dSbr_dVa) );
Hav = 2 * real( Sav + dSbr_dVa.' * diaglam * conj(dSbr_dVm) );
Hvv = 2 * real( Svv + dSbr_dVm.' * diaglam * conj(dSbr_dVm) );
