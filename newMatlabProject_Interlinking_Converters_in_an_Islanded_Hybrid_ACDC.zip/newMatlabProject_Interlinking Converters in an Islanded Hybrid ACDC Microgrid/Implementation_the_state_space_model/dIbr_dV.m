function [dIf_dVa, dIf_dVm, dIt_dVa, dIt_dVm, If, It] = dIbr_dV(branch, Yf, Yt, V)
nb = length(V);

Vnorm = V ./ abs(V);
if issparse(Yf)             %% sparse version (if Yf is sparse)
    diagV       = sparse(1:nb, 1:nb, V, nb, nb);
    diagVnorm   = sparse(1:nb, 1:nb, Vnorm, nb, nb);
else                        %% dense version
    diagV       = diag(V);
    diagVnorm   = diag(Vnorm);
end
dIf_dVa = Yf * 1j * diagV;
dIf_dVm = Yf * diagVnorm;
dIt_dVa = Yt * 1j * diagV;
dIt_dVm = Yt * diagVnorm;

%% compute currents
if nargout > 4
    If = Yf * V;
    It = Yt * V;
end
