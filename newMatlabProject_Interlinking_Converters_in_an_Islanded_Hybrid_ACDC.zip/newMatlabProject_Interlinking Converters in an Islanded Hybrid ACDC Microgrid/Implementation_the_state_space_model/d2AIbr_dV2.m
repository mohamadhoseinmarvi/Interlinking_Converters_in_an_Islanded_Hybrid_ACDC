function [Haa, Hav, Hva, Hvv] = ...
    d2AIbr_dV2(dIbr_dVa, dIbr_dVm, Ibr, Ybr, V, lam)

nl = length(lam);

diaglam = sparse(1:nl, 1:nl, lam, nl, nl);
diagIbr_conj = sparse(1:nl, 1:nl, conj(Ibr), nl, nl);

[Iaa, Iav, Iva, Ivv] = d2Ibr_dV2(Ybr, V, diagIbr_conj * lam);
Haa = 2 * real( Iaa + dIbr_dVa.' * diaglam * conj(dIbr_dVa) );
Hva = 2 * real( Iva + dIbr_dVm.' * diaglam * conj(dIbr_dVa) );
Hav = 2 * real( Iav + dIbr_dVa.' * diaglam * conj(dIbr_dVm) );
Hvv = 2 * real( Ivv + dIbr_dVm.' * diaglam * conj(dIbr_dVm) );
