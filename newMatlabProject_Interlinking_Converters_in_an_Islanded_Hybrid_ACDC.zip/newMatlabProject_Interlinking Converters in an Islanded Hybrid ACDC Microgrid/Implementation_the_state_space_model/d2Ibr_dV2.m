function [Haa, Hav, Hva, Hvv] = d2Ibr_dV2(Ybr, V, lam)

nb = length(V);

diaginvVm = sparse(1:nb, 1:nb, ones(nb, 1)./abs(V), nb, nb);

Haa = sparse(1:nb, 1:nb, -(Ybr.' * lam) .* V, nb, nb);
Hva = -1j * Haa * diaginvVm;
Hav = Hva;
Hvv = sparse(nb, nb);
