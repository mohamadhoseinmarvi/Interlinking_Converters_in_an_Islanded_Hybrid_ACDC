function [V, converged, i] = fdpf(Ybus, Sbus, V0, Bp, Bpp, ref, pv, pq, mpopt)

if nargin < 7
    mpopt = mpoption;
end


tol     = mpopt(2);
max_it  = mpopt(4);
verbose = mpopt(31);

converged = 0;
i = 0;
V = V0;
Va = angle(V);
Vm = abs(V);

npv = length(pv);
npq = length(pq);

mis = (V .* conj(Ybus * V) - Sbus) ./ Vm;
P = real(mis([pv; pq]));
Q = imag(mis(pq));

normP = norm(P, inf);
normQ = norm(Q, inf);
if verbose > 0
    alg = mpopt(1);
    if mpopt(1) == 2, s = 'XB'; else, s = 'BX'; end
    fprintf('(fast-decoupled, %s)\n', s);
end
if verbose > 1
    fprintf('\niteration     max mismatch (p.u.)  ');
    fprintf('\ntype   #        P            Q     ');
    fprintf('\n---- ----  -----------  -----------');
    fprintf('\n  -  %3d   %10.3e   %10.3e', i, normP, normQ);
end
if normP < tol && normQ < tol
    converged = 1;
    if verbose > 1
        fprintf('\nConverged!\n');
    end
end

Bp = Bp([pv; pq], [pv; pq]);
Bpp = Bpp(pq, pq);

[Lp, Up, Pp] = lu(Bp);
[Lpp, Upp, Ppp] = lu(Bpp);

while (~converged && i < max_it)
    i = i + 1;

    dVa = -( Up \  (Lp \ (Pp * P)));

    Va([pv; pq]) = Va([pv; pq]) + dVa;
    V = Vm .* exp(1j * Va);

    mis = (V .* conj(Ybus * V) - Sbus) ./ Vm;
    P = real(mis([pv; pq]));
    Q = imag(mis(pq));
    
    normP = norm(P, inf);
    normQ = norm(Q, inf);
    if verbose > 1
        fprintf('\n  P  %3d   %10.3e   %10.3e', i, normP, normQ);
    end
    if normP < tol && normQ < tol
        converged = 1;
        if verbose
            fprintf('\nFast-decoupled power flow converged in %d P-iterations and %d Q-iterations.\n', i, i-1);
        end
        break;
    end


    dVm = -( Upp \ (Lpp \ (Ppp * Q)) );


    Vm(pq) = Vm(pq) + dVm;
    V = Vm .* exp(1j * Va);


    mis = (V .* conj(Ybus * V) - Sbus) ./ Vm;
    P = real(mis([pv; pq]));
    Q = imag(mis(pq));
    
    normP = norm(P, inf);
    normQ = norm(Q, inf);
    if verbose > 1
        fprintf('\n  Q  %3d   %10.3e   %10.3e', i, normP, normQ);
    end
    if normP < tol && normQ < tol
        converged = 1;
        if verbose
            fprintf('\nFast-decoupled power flow converged in %d P-iterations and %d Q-iterations.\n', i, i);
        end
        break;
    end
end

if verbose
    if ~converged
        fprintf('\nFast-decoupled power flow did not converge in %d iterations.\n', i);
    end
end
