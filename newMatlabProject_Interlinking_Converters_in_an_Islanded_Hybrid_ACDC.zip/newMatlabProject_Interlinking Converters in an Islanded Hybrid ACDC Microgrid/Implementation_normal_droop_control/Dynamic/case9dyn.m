function [gen,exc,gov,mmc,DCVolCon,OutCurCon,CirCurCon,freq,stepsize,stoptime] = case9dyn

freq = 50;
stepsize = 0.0001;
stoptime = 5;

gen=[2  2   1   1.20   0.02   0.14    0.14   0.25    0.25    5.2 0.81;
     2  2   1   2.40   0.01   0.14    0.14   0.25    0.25    5.2 0.81;
     2  2   1   5.74   0.02   1.93    1.77    0.25    0.25    5.2 0.81;
];

exc=[1 50 0.05    -0.17   0.95    0.04    1   0.014   1.55    -1.7    1.7;
     2 50 0.05    -0.17   0.95    0.04    1   0.014   1.55    -1.7    1.7;
     3 50 0.05    -0.17   0.95    0.04    1   0.014   1.55    -1.7    1.7;
];

gov=[1  0   0   0   0   0   0   0   0;
     2  0   0   0   0   0   0   0   0;
     3  0   0   0   0   0   0   0   0;
];

mmc = [12 3 140e3 70e3 2e3 0];

Ra = 20;
alpha2 = 200;
CirCurCon = [Ra alpha2];

alpha_c = 1000;
alpha_1 = 100;
OutCurCon = [alpha_c alpha_1];

alpha_d = 50;
alpha_id = 25;
DCVolCon = [alpha_d alpha_id];

return;