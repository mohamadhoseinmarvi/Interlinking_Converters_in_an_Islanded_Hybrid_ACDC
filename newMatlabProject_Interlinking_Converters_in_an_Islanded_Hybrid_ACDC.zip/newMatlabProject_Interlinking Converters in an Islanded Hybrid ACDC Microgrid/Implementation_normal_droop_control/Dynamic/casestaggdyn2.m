function [gen,exc,gov,freq,stepsize,stoptime] = casestaggdyn2

freq=60;
stepsize = 0.01;
stoptime=.9;

gen=[2  2   1   50   0   1.93    1.77    0.25    0.25    5.2 0.81;
     2  1   1   1    0   1.93    1.77    1.50    1.50    5.2 0.81];
 

exc=[1  50 0.05    -0.17   0.95    0.04    1   0.014   1.55    -1.7    1.7;
     2  0   0       0       0       0       0   0       0       0       0];
 

gov=[1 0 0 0 0 0 0 0 0;
     2 0 0 0 0 0 0 0 0];

return;