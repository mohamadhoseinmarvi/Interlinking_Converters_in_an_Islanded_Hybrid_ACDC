function [gen,exc,gov,freq,stepsize,stoptime] = casestaggdyn

freq=60;
stepsize = 0.02;
stoptime=.9;

gen=[1  1   1   50   0   0.25    0.25    0    0    0 0;
     1  1   1    1   0   1.50    1.50    0    0    0 0];
 

exc=[1  0 0 0 0 0 0 0 0 0 0;
     2  0 0 0 0 0 0 0 0 0 0];
 

gov=[1 0 0 0 0 0 0 0 0;
     2 0 0 0 0 0 0 0 0];

return;