function [event,buschange,linechange] = staggevent

event=[0.0      1; 
       0.0      1;
       0.1      1;
       0.1      1];


buschange   = [0.0  2  6  -1e10;
               0.0  2  5  1e10;
               0.1  2  6  0   ;
               0.1  2  5  0 ];


linechange = [];

return;