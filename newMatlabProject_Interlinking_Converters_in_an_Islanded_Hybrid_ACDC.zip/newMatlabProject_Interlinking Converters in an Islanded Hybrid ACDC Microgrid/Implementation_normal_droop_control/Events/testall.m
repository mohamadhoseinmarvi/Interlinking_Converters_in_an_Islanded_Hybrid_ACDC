function [event,buschange,linechange] = testall

event = [

        1.2     2;
        1.2     2;
        1.2     2];

buschange = [];

linechange = [1.2  2   3   0.1;
              1.2  2   4   0.2;
              1.2  2   5   0.3];
% linechange = [];

return;