function [Xexc0,Pexc0] = ExciterInit(Xexc, Pexc, Vexc, exctype)


[ngen,c] = size(Xexc);
Xexc0 = zeros(ngen,c);
[ngen,c] = size(Pexc);
Pexc0 = zeros(ngen,c+2);
d=[1:length(exctype)]';


type1 = d(exctype==1);
type2 = d(exctype==2);

Efd0 = Xexc(type1,1);
Xexc0(type1,1) = Efd0;
  
Efd0 = Xexc(type2,1);
Ka = Pexc(type2,2);
Ta = Pexc(type2,3);
Ke = Pexc(type2,4);
Te = Pexc(type2,5);
Kf = Pexc(type2,6);
Tf = Pexc(type2,7);
Aex = Pexc(type2,8);
Bex = Pexc(type2,9);
Ur_min = Pexc(type2,10);
Ur_max = Pexc(type2,11);
        
U = Vexc(type2,1);
        
Uf = zeros(length(type2),1);
Ux = Aex.*exp(Bex.*Efd0);
Ur = Ux+Ke.*Efd0;
Uref2 = U + (Ux+Ke.*Efd0)./Ka - U;
Uref = U;

Xexc0(type2,1:3) = [Efd0, Uf, Ur];   
Pexc0(type2,1:13) = [Pexc(type2,1), Ka, Ta, Ke, Te, Kf, Tf, Aex, Bex, Ur_min, Ur_max, Uref, Uref2];   



return;